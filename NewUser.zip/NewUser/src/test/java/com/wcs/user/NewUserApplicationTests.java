package com.wcs.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
